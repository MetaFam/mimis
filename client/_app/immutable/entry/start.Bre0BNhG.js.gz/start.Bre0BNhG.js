import{l as o,f as r}from"../chunks/Cv7WNtG6.js";export{o as load_css,r as start};

import{l as o,f as r}from"../chunks/Dq90KJw9.js";export{o as load_css,r as start};

import{J as e}from"./BGk_9FmB.js";const n="5";typeof window<"u"&&((window.__svelte??={}).v??=new Set).add(n);e();
